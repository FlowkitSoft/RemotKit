#!/usr/bin/env python3
"""
RemotKit - Universal Launcher
Cukup jalankan: python run.py
"""

import os
import sys
import subprocess
import socket
import requests

# ========== KONFIGURASI ==========
DEFAULT_PORT = 5000

# ========== DETEKSI TUNNEL ==========
def is_tunnel_active():
    """Deteksi apakah ada tunnel yang berjalan (Ngrok/Serveo/Cloudflare)"""
    
    # Cek apakah ada proses ngrok
    if os.name == 'nt':  # Windows
        try:
            result = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq ngrok.exe'], 
                                   capture_output=True, text=True)
            if 'ngrok.exe' in result.stdout:
                return True
        except:
            pass
    else:  # Linux/Mac
        try:
            result = subprocess.run(['pgrep', '-f', 'ngrok'], capture_output=True)
            if result.returncode == 0:
                return True
        except:
            pass
    
    # Cek port 4040 (Ngrok dashboard)
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex(('127.0.0.1', 4040))
        sock.close()
        if result == 0:
            return True
    except:
        pass
    
    return False

# ========== DETEKSI AKSES PUBLIK ==========
def is_public_network():
    """Deteksi apakah server di jaringan publik (VPS) atau lokal"""
    
    # Cek apakah ada tunnel
    if is_tunnel_active():
        return False  # Jika ada tunnel, tetap pakai mode development
    
    # Cek IP address server
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        
        # IP lokal: 192.168.x.x, 10.x.x.x, 172.16-31.x.x, 127.x.x.x
        is_local = (ip.startswith('192.168.') or 
                   ip.startswith('10.') or 
                   ip.startswith('127.') or
                   (ip.startswith('172.') and 16 <= int(ip.split('.')[1]) <= 31))
        
        # Jika bukan lokal, dan tidak ada tunnel → publik
        return not is_local
    except:
        return False

# ========== CEK FILE YANG DIPERLUKAN ==========
def check_required_files():
    """Cek apakah semua file yang diperlukan ada"""
    required = ['_server.py', 'agent.py', 'builder.py']
    missing = []
    
    for file in required:
        if not os.path.exists(os.path.join(os.path.dirname(__file__), file)):
            missing.append(file)
    
    if missing:
        print("=" * 55)
        print("❌ ERROR: Missing required files!")
        print("=" * 55)
        for file in missing:
            print(f"   - {file}")
        print("=" * 55)
        print("📌 Make sure all RemotKit files are in the same folder")
        return False
    
    return True

# ========== JALANKAN DENGAN FLASK (DEVELOPMENT) ==========
def run_flask():
    """Jalankan server dengan Flask development server"""
    
    print("=" * 55)
    print("🔧 RemotKit - Running")
    print("=" * 55)
    print(f"📡 Server: http://localhost:{DEFAULT_PORT}")
    
    # Tampilkan info akses
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        print(f"🏠 Local access: http://{local_ip}:{DEFAULT_PORT}")
    except:
        pass
    
    # Cek tunnel
    if is_tunnel_active():
        print("🌐 Tunnel detected - Accessible from internet via tunnel URL")
    else:
        print("⚠️  For internet access without tunnel, use: python run.py --prod")
    
    print("🔌 Press Ctrl+C to stop")
    print("=" * 55)
    
    # Filter warning
    import warnings
    import logging
    logging.getLogger('werkzeug').setLevel(logging.ERROR)
    warnings.filterwarnings("ignore", message=".*development server.*")
    
    # Import dan jalankan server
    from _server import app, socketio
    socketio.run(app, host='0.0.0.0', port=DEFAULT_PORT, debug=False)

# ========== JALANKAN DENGAN GUNICORN (PRODUCTION) ==========
def run_gunicorn():
    """Jalankan server dengan Gunicorn + Eventlet untuk production"""
    
    print("=" * 55)
    print("🚀 RemotKit - Production Mode")
    print("=" * 55)
    print(f"📡 Server: http://0.0.0.0:{DEFAULT_PORT}")
    
    # Tampilkan IP publik
    try:
        response = requests.get('https://api.ipify.org', timeout=5)
        public_ip = response.text.strip()
        print(f"🌍 Public access: http://{public_ip}:{DEFAULT_PORT}")
    except:
        pass
    
    print("✅ Ready - Accessible from internet")
    print("🔌 Press Ctrl+C to stop")
    print("=" * 55)
    
    # Cek dan install gunicorn
    try:
        subprocess.run([sys.executable, "-m", "gunicorn", "--version"], 
                      capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("📦 Setting up production server...")
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "gunicorn", "eventlet"])
        print("✅ Ready")
    
    # Jalankan Gunicorn
    cmd = [
        sys.executable, "-m", "gunicorn",
        "--worker-class", "eventlet",
        "-w", "1",
        "--bind", f"0.0.0.0:{DEFAULT_PORT}",
        "--access-logfile", "-",
        "--error-logfile", "-",
        "_server:app"
    ]
    
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        print("\n🛑 Server stopped")

# ========== MAIN ==========
def main():
    global DEFAULT_PORT
    
    # Ambil port dari argumen jika ada
    for arg in sys.argv[1:]:
        if arg.isdigit():
            DEFAULT_PORT = int(arg)
            break
    
    # Cek file yang diperlukan
    if not check_required_files():
        sys.exit(1)
    
    # Pilih mode secara otomatis
    if is_public_network():
        # Di VPS atau IP publik, pakai production
        run_gunicorn()
    else:
        # Di lokal, pakai flask (tunnel tetap bisa)
        run_flask()

if __name__ == "__main__":
    main()